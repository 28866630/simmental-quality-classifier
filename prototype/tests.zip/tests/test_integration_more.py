import io
from pathlib import Path
import numpy as np
from PIL import Image
import pytest
from cow_api.server import app

SAMPLES = Path(__file__).parent / "samples"
COW_IMG = SAMPLES / "cow.jpg"
NOCOW_IMG = SAMPLES / "nocow.jpg"
CORRUPT_IMG = SAMPLES / "corrupt.jpg"
OVERSIZED_IMG = SAMPLES / "oversized.jpg"  # kept for future use

def _load_bytes(p: Path) -> bytes:
    with open(p, "rb") as f:
        return f.read()

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_multiple_images_sequential_isolation_real():
    client = app.test_client()

    img1 = _load_bytes(COW_IMG)
    r1 = client.post("/predict", data={"image": (io.BytesIO(img1), "cow_1.jpg")},
                     content_type="multipart/form-data")
    assert r1.status_code == 200, r1.data
    p1 = r1.get_json()
    assert set(p1.keys()) == {"prediction", "score", "model_used"}
    assert 0.0 <= float(p1["score"]) <= 1.0

    if NOCOW_IMG.exists():
        img2 = _load_bytes(NOCOW_IMG)
        r2 = client.post("/predict", data={"image": (io.BytesIO(img2), "nocow.jpg")},
                         content_type="multipart/form-data")
        assert r2.status_code == 400
        assert "No cow detected" in r2.get_json()["error"]

    r3 = client.post("/predict", data={"image": (io.BytesIO(img1), "cow_2.jpg")},
                     content_type="multipart/form-data")
    assert r3.status_code == 200
    p3 = r3.get_json()
    assert set(p3.keys()) == {"prediction", "score", "model_used"}
    assert 0.0 <= float(p3["score"]) <= 1.0

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_single_cow_mode_average_client_side_real():
    client = app.test_client()
    img = _load_bytes(COW_IMG)
    scores = []
    for i in range(3):
        r = client.post("/predict", data={"image": (io.BytesIO(img), f"cow_repeat_{i}.jpg")},
                        content_type="multipart/form-data")
        assert r.status_code == 200
        scores.append(float(r.get_json()["score"]))
    avg = sum(scores) / len(scores)
    label = "Good" if avg >= 0.5 else "Bad"
    assert 0.0 <= avg <= 1.0
    assert label in ("Good", "Bad")
    print(f"[TEST] single-cow avg -> label={label}, avg_score={avg:.4f}")

# ⬇️ Skipped per your request (kept for future runs)
@pytest.mark.skip(reason="Oversized image test disabled for current runs")
@pytest.mark.skipif(not OVERSIZED_IMG.exists(), reason="Missing tests/samples/oversized.jpg")
def test_oversized_image_stress_real():
    client = app.test_client()
    r = client.post("/predict",
                    data={"image": (open(OVERSIZED_IMG, "rb"), "oversized.jpg")},
                    content_type="multipart/form-data")
    assert r.status_code in (200, 400)
    payload = r.get_json()
    if r.status_code == 200:
        assert set(payload.keys()) == {"prediction", "score", "model_used"}
        assert 0.0 <= float(payload["score"]) <= 1.0
    else:
        assert "error" in payload
    print(f"[TEST] oversized.jpg -> {payload}")

@pytest.mark.skipif(not CORRUPT_IMG.exists(), reason="Missing tests/samples/corrupt.jpg")
def test_corrupt_image_real():
    client = app.test_client()
    r = client.post("/predict",
                    data={"image": (open(CORRUPT_IMG, "rb"), "corrupt.jpg")},
                    content_type="multipart/form-data")
    assert r.status_code == 400
    payload = r.get_json()
    assert payload["error"] == "Could not read image"
    print(f"[TEST] corrupt.jpg -> {payload}")

def test_unsupported_file_type_real():
    client = app.test_client()
    bogus = io.BytesIO(b"this is not an image file, just some text data")
    r = client.post("/predict",
                    data={"image": (bogus, "notes.txt")},
                    content_type="multipart/form-data")
    assert r.status_code == 400
    payload = r.get_json()
    assert payload["error"] == "Could not read image"
    print(f"[TEST] notes.txt -> {payload}")
