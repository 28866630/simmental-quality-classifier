import os
import io
import time
import json
import random
import string
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

# ======= CONFIG =======
ENDPOINT_SINGLE = "http://127.0.0.1:5050/predict"
ENDPOINT_MULTI  = "http://127.0.0.1:5050/predict-multiple"

SAMPLES_DIR = Path(__file__).resolve().parents[1] / "tests" / "samples"
SINGLE_FIELD = "image"
MULTI_FIELD  = "images"

# How hard to hammer
DURATION_SECONDS = 60       # total runtime
MAX_WORKERS      = 10        # concurrent threads
P_MULTI_PROB     = 0.35     # probability to use /predict-multiple
P_MALFORMED      = 0.10     # probability to send a malformed request
BATCH_MIN, BATCH_MAX = 2, 6 # size of multi-image batches
# ======================

# Files to pick from (real ones)
PREFERRED_IMAGES = [
    "cow.jpg", "cow2.jpg", "cow3.jpg", "cow4.jpg", "nocow.jpg"
]
EXTRA_BAD = ["corrupt.jpg", "notes.txt"]  # keep some nasties in the mix

def _load_bytes(path: Path) -> bytes:
    with open(path, "rb") as f:
        return f.read()

def _choose_files_for_batch():
    candidates = [p for p in (PREFERRED_IMAGES + EXTRA_BAD) if (SAMPLES_DIR / p).exists()]
    k = random.randint(BATCH_MIN, BATCH_MAX)
    picks = random.choices(candidates, k=k)
    return [(SAMPLES_DIR / name) for name in picks]

def _rand_sleep_jitter():
    # Short human-ish jitter between 20–200 ms
    time.sleep(random.uniform(0.02, 0.20))

def _post_single():
    # Randomly pick a file (mix of good/bad)
    name = random.choice(PREFERRED_IMAGES + EXTRA_BAD)
    path = SAMPLES_DIR / name
    if not path.exists():
        return {"ok": False, "where": "single", "name": name, "err": "missing_file"}

    # Sometimes send a malformed request (missing 'image', bad content-type, or empty body)
    if random.random() < P_MALFORMED:
        choice = random.choice(["missing_field", "wrong_content_type", "empty_body"])
        try:
            if choice == "missing_field":
                r = requests.post(ENDPOINT_SINGLE, files={})  # no 'image'
            elif choice == "wrong_content_type":
                r = requests.post(ENDPOINT_SINGLE, data={"image": "not-a-file"})
            else:
                r = requests.post(ENDPOINT_SINGLE, data=b"", headers={"Content-Type": "application/octet-stream"})
            return {"ok": r.status_code in (400, 415), "where": "single", "name": choice, "status": r.status_code, "body": r.text[:200]}
        except Exception as e:
            return {"ok": False, "where": "single", "name": choice, "err": str(e)}

    # Normal single upload
    try:
        files = {SINGLE_FIELD: (name, _load_bytes(path))}
        r = requests.post(ENDPOINT_SINGLE, files=files, timeout=30)
        ok = (r.status_code in (200, 400))
        # we accept 400 for "No cow detected" / "Could not read image"
        return {"ok": ok, "where": "single", "name": name, "status": r.status_code, "body": r.text[:200]}
    except Exception as e:
        return {"ok": False, "where": "single", "name": name, "err": str(e)}

def _post_batch():
    # Sometimes send malformed multi requests
    if random.random() < P_MALFORMED:
        choice = random.choice(["missing_field", "wrong_content_type"])
        try:
            if choice == "missing_field":
                r = requests.post(ENDPOINT_MULTI, files={})  # no 'images'
            else:
                r = requests.post(ENDPOINT_MULTI, data={"images": "not-files"})
            return {"ok": r.status_code in (400, 415), "where": "multi", "name": choice, "status": r.status_code, "body": r.text[:200]}
        except Exception as e:
            return {"ok": False, "where": "multi", "name": choice, "err": str(e)}

    # Normal multi upload
    picks = _choose_files_for_batch()
    files = []
    for p in picks:
        # Every tuple is (field_name, (filename, filebytes))
        files.append((MULTI_FIELD, (p.name, _load_bytes(p))))

    try:
        r = requests.post(ENDPOINT_MULTI, files=files, timeout=60)
        ok = (r.status_code == 200)
        # Expect a list of results; each item either has prediction+score or "No cow detected"
        return {"ok": ok, "where": "multi", "names": [p.name for p in picks], "status": r.status_code, "body": r.text[:200]}
    except Exception as e:
        return {"ok": False, "where": "multi", "names": [p.name for p in picks], "err": str(e)}

def worker(stop_time, results, lock):
    while time.time() < stop_time:
        _rand_sleep_jitter()
        if random.random() < P_MULTI_PROB:
            res = _post_batch()
        else:
            res = _post_single()
        with lock:
            results.append(res)

def summarize(results):
    total = len(results)
    ok = sum(1 for r in results if r.get("ok"))
    err = total - ok
    singles = sum(1 for r in results if r.get("where") == "single")
    multis  = sum(1 for r in results if r.get("where") == "multi")
    statuses = {}
    for r in results:
        s = r.get("status", "NA")
        statuses[s] = statuses.get(s, 0) + 1

    print("\n=== MONKEY SUMMARY ===")
    print(f"Total requests: {total} | OK: {ok} | Err: {err}")
    print(f"Singles: {singles} | Batches: {multis}")
    print("By status:", statuses)
    # Print a few failures for inspection
    bad = [r for r in results if not r.get("ok")]
    for r in bad[:5]:
        print("  !", r)

def main():
    if not SAMPLES_DIR.exists():
        raise SystemExit(f"Samples dir not found: {SAMPLES_DIR}")

    print(f"Monkey test -> duration={DURATION_SECONDS}s, workers={MAX_WORKERS}, multi_prob={P_MULTI_PROB}, malformed_prob={P_MALFORMED}")
    stop_time = time.time() + DURATION_SECONDS
    results = []
    lock = threading.Lock()

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = [ex.submit(worker, stop_time, results, lock) for _ in range(MAX_WORKERS)]
        for _ in as_completed(futs):
            pass

    summarize(results)

if __name__ == "__main__":
    main()
