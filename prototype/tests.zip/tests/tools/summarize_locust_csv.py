#!/usr/bin/env python3
import csv, sys, re, pathlib

# Usage: python tools/summarize_locust_csv.py results_u5_stats.csv results_u10_stats.csv ...

# Columns vary slightly by Locust version; we’ll look up by a few aliases
ALIASES = {
    "avg": ["Average Response Time", "Average response time"],
    "p95": ["95%", "95"],
    "p99": ["99%", "99"],
    "rps": ["Requests/s", "Requests per second", "Requests/s "],
    "req": ["Requests", "Request Count"],
    "fail": ["Failures", "Failure Count"],
    "name": ["Name"],
}

def pick(row, keys):
    for k in keys:
        if k in row and row[k] != "":
            return row[k]
    # try case-insensitive fallback
    lower = {k.lower(): v for k, v in row.items()}
    for k in keys:
        if k.lower() in lower and lower[k.lower()] != "":
            return lower[k.lower()]
    return None

def parse_stats_csv(path):
    with open(path, newline="") as f:
        rdr = csv.DictReader(f)
        rows = list(rdr)

    # Prefer the aggregated/total row; fall back to last row if unsure
    agg = None
    for r in rows:
        nm = (pick(r, ALIASES["name"]) or "").strip().lower()
        if nm in ("aggregated", "total", "::aggregated"):
            agg = r
            break
    if agg is None:
        agg = rows[-1]

    def num(x, default=None):
        try:
            return float(str(x).strip())
        except Exception:
            return default

    avg  = num(pick(agg, ALIASES["avg"]))
    p95  = num(pick(agg, ALIASES["p95"]))
    p99  = num(pick(agg, ALIASES["p99"]))
    rps  = num(pick(agg, ALIASES["rps"]))
    reqs = num(pick(agg, ALIASES["req"]), 0.0)
    fail = num(pick(agg, ALIASES["fail"]), 0.0)
    fail_pct = (fail / reqs * 100.0) if reqs else 0.0

    # infer users from filename like results_u10_stats.csv
    m = re.search(r"_u(\d+)_", path.name)
    users = int(m.group(1)) if m else None

    return {
        "file": path.name,
        "users": users,
        "avg_ms": avg,
        "p95_ms": p95,
        "p99_ms": p99,
        "rps": rps,
        "fail_pct": fail_pct,
        "reqs": reqs,
        "fails": fail,
    }

def main(paths):
    rows = [parse_stats_csv(pathlib.Path(p)) for p in paths]
    # sort by users if present, else by filename
    rows.sort(key=lambda r: (r["users"] is None, r["users"] or 0, r["file"]))

    # Markdown table
    print("\n# Performance Summary (Markdown)")
    print("| Concurrent Users | Avg Latency (ms) | P95 (ms) | P99 (ms) | Requests/sec | Failures (%) |")
    print("|---:|---:|---:|---:|---:|---:|")
    for r in rows:
        print(f"| {r['users'] if r['users'] is not None else r['file']} "
              f"| {r['avg_ms']:.1f} | {r['p95_ms']:.1f} | {r['p99_ms']:.1f} "
              f"| {r['rps']:.2f} | {r['fail_pct']:.2f} |")

    # LaTeX table
    print("\n% Performance Summary (LaTeX)")
    print("\\begin{tabular}{r r r r r r}")
    print("\\toprule")
    print("Users & Avg (ms) & P95 (ms) & P99 (ms) & Req/s & Fail (\\%)\\\\")
    print("\\midrule")
    for r in rows:
        users = r['users'] if r['users'] is not None else r['file']
        print(f"{users} & {r['avg_ms']:.1f} & {r['p95_ms']:.1f} & {r['p99_ms']:.1f} & {r['rps']:.2f} & {r['fail_pct']:.2f}\\\\")
    print("\\bottomrule")
    print("\\end{tabular}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tools/summarize_locust_csv.py results_u5_stats.csv results_u10_stats.csv ...")
        sys.exit(2)
    main(sys.argv[1:])
