# app/tools/locustfile.py
from locust import HttpUser, task, between
from pathlib import Path
import random

# ======== CONFIGURE HERE ========
SAMPLES_DIR = Path(__file__).resolve().parents[1] / "tests" / "samples"
SINGLE_FIELD = "image"
MULTI_FIELD  = "images"

# Task mix: how frequently to hit each endpoint
WEIGHT_SINGLE = 3   # /predict
WEIGHT_MULTI  = 1   # /predict-multiple

# For /predict-multiple batches
BATCH_MIN = 2
BATCH_MAX = 4
# =================================

# preload image bytes once per worker
def _load_image_bytes():
    names = ["cow.jpg", "cow2.jpg", "cow3.jpg", "cow4.jpg"]
    imgs = []
    for n in names:
        p = SAMPLES_DIR / n
        if p.exists():
            imgs.append((n, p.read_bytes()))
    if not imgs:
        raise RuntimeError(f"No images found in {SAMPLES_DIR}")
    return imgs

IMAGES = _load_image_bytes()

class CattleApiUser(HttpUser):
    # short, realistic pauses reduce artificial client pileups
    wait_time = between(0.05, 0.2)

    @task(WEIGHT_SINGLE)
    def predict_single(self):
        name, data = random.choice(IMAGES)
        files = {SINGLE_FIELD: (name, data)}
        # count success on both 200 OK and 400 only if you want to include errors;
        # here we expect 200 for valid images.
        with self.client.post("/predict", files=files, catch_response=True) as resp:
            if resp.status_code == 200:
                resp.success()
            else:
                resp.failure(f"Unexpected status {resp.status_code}: {resp.text[:120]}")

    @task(WEIGHT_MULTI)
    def predict_multiple(self):
        k = random.randint(BATCH_MIN, BATCH_MAX)
        picks = random.choices(IMAGES, k=k)  # keep order
        files = []
        for name, data in picks:
            # Each file as (field_name, (filename, bytes))
            files.append((MULTI_FIELD, (name, data)))
        with self.client.post("/predict-multiple", files=files, catch_response=True) as resp:
            if resp.status_code == 200:
                resp.success()
            else:
                resp.failure(f"Unexpected status {resp.status_code}: {resp.text[:120]}")
