# app/tools/ui_locust.py
import os, random
from pathlib import Path
from locust import User, task, between
from playwright.sync_api import sync_playwright

APP_URL = os.getenv("APP_URL", "http://127.0.0.1:8000")  # serve your Flutter web app
SAMPLES_DIR = Path(__file__).resolve().parents[1] / "tests" / "samples"
IMG_NAMES = ["cow.jpg", "cow2.jpg", "cow3.jpg", "cow4.jpg", "nocow.jpg"]

def existing_sample_paths():
    return [str(SAMPLES_DIR / n) for n in IMG_NAMES if (SAMPLES_DIR / n).exists()]

class UiUser(User):
    wait_time = between(0.3, 1.0)

    def on_start(self):
        self.pw = sync_playwright().start()
        self.browser = self.pw.chromium.launch(headless=True)
        self.ctx = self.browser.new_context(viewport={"width": 1200, "height": 2200})
        self.page = self.ctx.new_page()
        self.page.goto(APP_URL)

    def on_stop(self):
        self.ctx.close()
        self.browser.close()
        self.pw.stop()

    def _pick_images(self, k=3):
        picks = random.sample(existing_sample_paths(), k=k)
        with self.page.expect_file_chooser() as fc:
            self.page.get_by_role("button", name="Pick up to 10 Images").click()
        fc.value.set_files(picks)

    def _predict(self):
        self.page.get_by_role("button", name="Predict All").click()

    def _clear_all(self):
        btn = self.page.get_by_role("button", name="Clear all")
        if btn.count():
            btn.click()

    def _close_random_tile(self):
        # try a handful of indices; relies on Semantics(label: 'tile-close-<i>')
        for i in random.sample(range(8), 8):
            loc = self.page.get_by_role("button", name=f"tile-close-{i}")
            if loc.count():
                loc.first.click()
                break

    @task(3)
    def flow_pick_predict(self):
        self._pick_images(k=random.randint(2, 5))
        self._predict()

    @task(2)
    def flow_remove_some(self):
        self._close_random_tile()
        if random.random() < 0.5:
            self._clear_all()
