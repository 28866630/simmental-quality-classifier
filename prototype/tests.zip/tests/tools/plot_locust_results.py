import csv
import re
import pathlib
import matplotlib.pyplot as plt

# === Paths to your CSV files ===
csv_files = [
    "results_u5_stats.csv",
    "results_u10_stats.csv",
    "results_u20_stats.csv"
]

# === Helper: Extract data from Locust stats CSV ===
def parse_csv(path):
    with open(path, newline="") as f:
        rdr = csv.DictReader(f)
        rows = list(rdr)

    # Pick the aggregated row
    agg_row = None
    for row in rows:
        name_val = row.get("Name") or row.get("name", "")
        if str(name_val).strip().lower() in ("aggregated", "total", "::aggregated"):
            agg_row = row
            break
    if agg_row is None:
        agg_row = rows[-1]

    # Safe getter
    def get_float(key_aliases):
        for key in key_aliases:
            if key in agg_row and agg_row[key]:
                try:
                    return float(agg_row[key])
                except:
                    pass
        return None

    # Extract metrics
    avg = get_float(["Average response time", "Average Response Time"])
    p95 = get_float(["95%", "95"])
    p99 = get_float(["99%", "99"])
    rps = get_float(["Requests/s", "Requests per second"])
    reqs = get_float(["Requests", "Request Count"])
    fails = get_float(["Failures", "Failure Count"])

    fail_pct = (fails / reqs * 100.0) if reqs else 0.0

    # Users from filename
    m = re.search(r"_u(\d+)_", path.name)
    users = int(m.group(1)) if m else None

    return users, avg, p95, p99, rps, fail_pct

# === Load all CSVs ===
data = []
for file in csv_files:
    users, avg, p95, p99, rps, fail_pct = parse_csv(pathlib.Path(file))
    data.append((users, avg, p95, p99, rps, fail_pct))

# Sort by user count
data.sort(key=lambda x: x[0])

# Separate lists for plotting
users = [d[0] for d in data]
avg_times = [d[1] for d in data]
p95_times = [d[2] for d in data]
p99_times = [d[3] for d in data]
rps_values = [d[4] for d in data]
fail_pcts = [d[5] for d in data]

# === Plot Latency ===
plt.figure(figsize=(8,5))
plt.plot(users, avg_times, marker='o', label='Average Latency (ms)')
plt.plot(users, p95_times, marker='s', label='P95 Latency (ms)')
plt.plot(users, p99_times, marker='^', label='P99 Latency (ms)')
plt.xlabel("Concurrent Users")
plt.ylabel("Latency (ms)")
plt.title("Latency vs Concurrent Users")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("latency_vs_users.png", dpi=300)

# === Plot Requests/sec ===
plt.figure(figsize=(8,5))
plt.plot(users, rps_values, marker='o', color='green')
plt.xlabel("Concurrent Users")
plt.ylabel("Requests/sec")
plt.title("Throughput vs Concurrent Users")
plt.grid(True)
plt.tight_layout()
plt.savefig("rps_vs_users.png", dpi=300)

# === Plot Failure % ===
plt.figure(figsize=(8,5))
plt.plot(users, fail_pcts, marker='o', color='red')
plt.xlabel("Concurrent Users")
plt.ylabel("Failure Rate (%)")
plt.title("Failure Rate vs Concurrent Users")
plt.grid(True)
plt.tight_layout()
plt.savefig("failrate_vs_users.png", dpi=300)

print("✅ Graphs saved: latency_vs_users.png, rps_vs_users.png, failrate_vs_users.png")
