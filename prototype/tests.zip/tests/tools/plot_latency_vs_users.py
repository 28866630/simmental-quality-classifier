import sys
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# Usage:
#   pip install pandas matplotlib
#   python tools/plot_latency_vs_users.py results/perf
#
# Expects CSVs like: results/perf/u5_stats.csv, u10_stats.csv, u20_stats.csv

USERS_SET = [5, 10, 20]

def get_total_row(df: pd.DataFrame) -> pd.Series:
    # Locust "aggregate" row is typically "Aggregated" or "Total"
    name_col = "Name" if "Name" in df.columns else "name"
    mask = df[name_col].astype(str).str.lower().isin(["aggregated", "total"])
    if mask.any():
        return df[mask].iloc[0]
    # fallback if single-row CSV
    if len(df) == 1:
        return df.iloc[0]
    raise RuntimeError("No Aggregated/Total row found")

def pick(row: pd.Series, *candidates, default=None):
    # case-insensitive column fallback
    cols = {c.lower(): c for c in row.index}
    for c in candidates:
        k = c.lower()
        if k in cols:
            return row[cols[k]]
    return default

def read_metrics(csv_path: Path) -> dict:
    df = pd.read_csv(csv_path)
    row = get_total_row(df)

    # Locust column names vary slightly across versions; try multiple keys
    p50 = pick(row, "Median Response Time", "50%", "p50", "median_response_time")
    p90 = pick(row, "90%", "p90", "90")
    p95 = pick(row, "95%", "p95", "95")
    p99 = pick(row, "99%", "p99", "99")
    avg = pick(row, "Average Response Time", "avg_response_time")
    rps = pick(row, "Requests/s", "requests/s", "Requests_per_second")
    req = pick(row, "Requests", "requests")
    fail = pick(row, "Failures", "failures")

    return {
        "p50": float(p50) if p50 is not None else None,
        "p90": float(p90) if p90 is not None else None,
        "p95": float(p95) if p95 is not None else None,
        "p99": float(p99) if p99 is not None else None,
        "avg": float(avg) if avg is not None else None,
        "rps": float(rps) if rps is not None else None,
        "requests": float(req) if req is not None else None,
        "failures": float(fail) if fail is not None else None,
    }

def main(outdir: Path):
    rows = []
    for users in USERS_SET:
        csv_path = outdir / f"u{users}_stats.csv"
        if not csv_path.exists():
            print(f"Missing: {csv_path} (skipping)")
            continue
        m = read_metrics(csv_path)
        m["users"] = users
        rows.append(m)

    if not rows:
        raise SystemExit("No runs found. Expected u5/u10/u20_stats.csv in output dir.")

    df = pd.DataFrame(rows).sort_values("users")
    # Save summary CSV
    summary = outdir / "latency_summary.csv"
    df.to_csv(summary, index=False)
    print(f"Wrote {summary}")

    # Plot latencies vs users (ms)
    plt.figure(figsize=(7.5, 4.5))
    for col, label, style in [
        ("p50", "p50 (median)", "-o"),
        ("p90", "p90", "-o"),
        ("p95", "p95", "-o"),
        ("p99", "p99", "--o"),
        ("avg", "average", "--o"),
    ]:
        if col in df.columns and df[col].notna().any():
            plt.plot(df["users"], df[col], style, label=label)

    plt.xlabel("Concurrent users")
    plt.ylabel("Latency (ms)")
    plt.title("API latency vs concurrent users")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    png = outdir / "latency_vs_users.png"
    plt.savefig(png, dpi=150)
    print(f"Wrote {png}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python tools/plot_latency_vs_users.py results/perf")
        raise SystemExit(2)
    main(Path(sys.argv[1]))
