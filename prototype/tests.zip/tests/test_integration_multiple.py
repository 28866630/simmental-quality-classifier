import io
from pathlib import Path
import pytest
from cow_api.server import app
import json  # for pretty printing

SAMPLES   = Path(__file__).parent / "samples"
COW_IMG   = SAMPLES / "cow.jpg"
NOCOW_IMG = SAMPLES / "nocow.jpg"
COW_IMG2  = SAMPLES / "cow2.jpg"
COW_IMG3  = SAMPLES / "cow3.jpg"
COW_IMG4  = SAMPLES / "cow4.jpg"

def _load_bytes(p: Path) -> bytes:
    with open(p, "rb") as f:
        return f.read()

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing samples")
def test_multiple_images_single_request_real():
    client = app.test_client()

    data = {
        "images": [
            (io.BytesIO(_load_bytes(COW_IMG)),   "cow.jpg"),
            (io.BytesIO(_load_bytes(NOCOW_IMG)), "nocow.jpg"),
            (io.BytesIO(_load_bytes(COW_IMG2)),  "cow2.jpg"),
            (io.BytesIO(_load_bytes(COW_IMG3)),  "cow3.jpg"),
            (io.BytesIO(_load_bytes(COW_IMG4)),  "cow4.jpg"),
        ]
    }

    # Flask/Werkzeug will build multipart/form-data automatically from file tuples.
    r = client.post("/predict-multiple", data=data, content_type="multipart/form-data")
    assert r.status_code == 200, r.data
    payload = r.get_json()

    # Debug: print the predictions
    print(json.dumps(payload, indent=2))

    assert isinstance(payload, list)
    assert len(payload) == 5

    for item in payload:
        assert "prediction" in item and "score" in item and "model_used" in item and "filename" in item
        if item["prediction"] in ("Good", "Bad"):
            assert item["score"] is not None
            assert 0.0 <= float(item["score"]) <= 1.0
        else:
            assert item["prediction"] == "No cow detected"
            assert item["score"] is None
        assert item["filename"] in {"cow.jpg", "nocow.jpg", "cow2.jpg", "cow3.jpg", "cow4.jpg"}
