from pathlib import Path
import io
import pytest
from cow_api.server import app  # reuse the same app

SAMPLES = Path(__file__).parent / "samples"
CORRUPT_IMG = SAMPLES / "corrupt.jpg"

@pytest.mark.skipif(not CORRUPT_IMG.exists(), reason="Missing tests/samples/corrupt.jpg")
def test_predict_corrupt_image_real_models(capfd):
    client = app.test_client()

    # Send the corrupt bytes
    with open(CORRUPT_IMG, "rb") as f:
        data = {"image": (io.BytesIO(f.read()), "corrupt.jpg")}
    resp = client.post("/predict", data=data, content_type="multipart/form-data")

    assert resp.status_code == 400
    payload = resp.get_json()
    assert "error" in payload
    assert payload["error"] == "Could not read image"

    # Also print for your terminal (pytest -s to see this)
    print("[TEST] corrupt.jpg ->", payload)

@pytest.mark.skipif(not (SAMPLES / "cow.jpg").exists(), reason="Missing tests/samples/cow.jpg")
def test_print_happy_path_payload():
    """Not a new assertion—just prints the payload so you can see score easily."""
    client = app.test_client()
    img_bytes = (SAMPLES / "cow.jpg").read_bytes()
    data = {"image": (io.BytesIO(img_bytes), "cow.jpg")}
    resp = client.post("/predict", data=data, content_type="multipart/form-data")
    assert resp.status_code == 200
    payload = resp.get_json()
    # print to terminal for visibility (use pytest -s)
    print("[TEST] cow.jpg ->", payload)

@pytest.mark.skipif(not (SAMPLES / "nocow.jpg").exists(), reason="Missing tests/samples/nocow.jpg")
def test_print_nocow_payload():
    client = app.test_client()
    img_bytes = (SAMPLES / "nocow.jpg").read_bytes()
    data = {"image": (io.BytesIO(img_bytes), "nocow.jpg")}
    resp = client.post("/predict", data=data, content_type="multipart/form-data")
    assert resp.status_code == 400
    payload = resp.get_json()
    print("[TEST] nocow.jpg ->", payload)
