import io
from pathlib import Path
import numpy as np
import pytest
from PIL import Image
from cow_api import server

SAMPLES = Path(__file__).parent / "samples"
COW_IMG   = SAMPLES / "cow.jpg"
NOCOW_IMG = SAMPLES / "nocow.jpg"

# ---------- resize_with_padding: padding color & extreme aspect ratios --------

def test_resize_with_padding_corners_are_white():
    """Corners should be white (255,255,255) after padding."""
    # Tall, narrow image so padding is added on sides
    arr = np.zeros((300, 50, 3), dtype=np.uint8) + 128  # mid-gray content
    out = server.resize_with_padding(arr, desired_size=224)
    h, w, _ = out.shape
    corners = np.array([out[0,0], out[0,w-1], out[h-1,0], out[h-1,w-1]], dtype=np.uint8)
    # allow tiny tolerance for interpolation
    assert np.all(corners >= 250), f"Corners not white: {corners}"

def test_resize_with_padding_extreme_wide_and_tall_shapes():
    """Extreme aspect ratios still yield 224x224 and preserve content scale."""
    # Very wide
    wide = np.zeros((40, 400, 3), dtype=np.uint8) + 200
    out_wide = server.resize_with_padding(wide, desired_size=224)
    assert out_wide.shape == (224, 224, 3)
    # Very tall
    tall = np.zeros((400, 40, 3), dtype=np.uint8) + 200
    out_tall = server.resize_with_padding(tall, desired_size=224)
    assert out_tall.shape == (224, 224, 3)

def test_resize_with_padding_tiny_input_1x1():
    """Even a 1x1 image must upscale and pad to 224x224 without errors."""
    tiny = np.array([[[123, 231, 45]]], dtype=np.uint8)  # 1x1 RGB
    out = server.resize_with_padding(tiny, desired_size=224)
    assert out.shape == (224, 224, 3)

# ---------- preprocess_image_with_yolo: decoding robustness -------------------

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_preprocess_accepts_jpeg_bytes_and_normalizes():
    """JPEG decoding -> preprocess -> normalized tensor."""
    b = COW_IMG.read_bytes()
    tensor = server.preprocess_image_with_yolo(b)
    assert tensor.shape == (1, 224, 224, 3)
    assert tensor.dtype == np.float32
    assert 0.0 <= float(tensor.min()) and float(tensor.max()) <= 1.0

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_preprocess_accepts_png_bytes_and_normalizes(tmp_path):
    """Save the same image as PNG in-memory and ensure pipeline still works."""
    # Convert cow.jpg -> PNG bytes in-memory
    img = Image.open(COW_IMG).convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    tensor = server.preprocess_image_with_yolo(buf.getvalue())
    assert tensor.shape == (1, 224, 224, 3)
    assert 0.0 <= float(tensor.min()) and float(tensor.max()) <= 1.0

# ---------- end-to-end: preprocessing + TFLite still bounded ------------------

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_inference_remains_bounded_across_formats():
    """Run JPEG and PNG of the same photo; both scores should be in [0,1]."""
    # JPEG
    t_jpg = server.preprocess_image_with_yolo(COW_IMG.read_bytes())
    server.interpreter_cow.set_tensor(server.input_details_cow[0]['index'], t_jpg)
    server.interpreter_cow.invoke()
    s_jpg = float(server.interpreter_cow.get_tensor(server.output_details_cow[0]['index'])[0][0])
    assert 0.0 <= s_jpg <= 1.0

    # PNG
    img = Image.open(COW_IMG).convert("RGB")
    buf = io.BytesIO(); img.save(buf, "PNG"); buf.seek(0)
    t_png = server.preprocess_image_with_yolo(buf.getvalue())
    server.interpreter_cow.set_tensor(server.input_details_cow[0]['index'], t_png)
    server.interpreter_cow.invoke()
    s_png = float(server.interpreter_cow.get_tensor(server.output_details_cow[0]['index'])[0][0])
    assert 0.0 <= s_png <= 1.0
