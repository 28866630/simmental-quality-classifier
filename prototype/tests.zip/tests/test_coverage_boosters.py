# tests/test_coverage_boosters.py
import io
import importlib
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
from PIL import Image


# ------------------------------ Helpers -------------------------------------

def _png_bytes(w=16, h=16, color=(255, 255, 255)):
    img = Image.new("RGB", (w, h), color)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class _CPUWrap:
    def __init__(self, arr): self._arr = arr
    def numpy(self): return self._arr

class _TensorWrap:
    """Emulate a tensor that supports indexing and .cpu().numpy()."""
    def __init__(self, arr):
        self._arr = np.array(arr)
    def cpu(self): return _CPUWrap(self._arr)
    def __getitem__(self, idx):
        return _TensorWrap(self._arr[idx])

class _Boxes:
    """Mimic Ultralytics Boxes with .cls and .xyxy that support .cpu().numpy()"""
    def __init__(self, cls_ids, xyxy):
        self.cls = _TensorWrap(np.array(cls_ids, dtype=np.float32))
        self.xyxy = _TensorWrap(np.array(xyxy, dtype=np.float32))

class _Masks:
    """Mimic masks with .data[i].cpu().numpy() -> 2D mask"""
    def __init__(self, mask_arrays):
        self.data = [ _TensorWrap(m) for m in mask_arrays ]

class _FakeResult:
    def __init__(self, boxes, masks, names=None, model_names=None):
        self.boxes = boxes
        self.masks = masks
        self.names = names
        self.model = SimpleNamespace(names=model_names or {})


# -------------------------- Fixtures: fresh imports --------------------------

@pytest.fixture
def fresh_server():
    """
    Reload cow_api.server freshly so routes are registered and any prior
    monkeypatch/reload side-effects are cleared.
    """
    import cow_api.server as server
    # A clean reload executes @app.route decorations again
    server = importlib.reload(server)
    return server


# ------------------------- 1) Startup sanity checks --------------------------

@pytest.mark.parametrize("missing", ["yolo", "tflite"])
def test_startup_missing_assets_triggers_file_error(monkeypatch, missing):
    """
    Covers import-time checks that raise FileNotFoundError when
    YOLO weights or TFLite model are missing.
    """
    # Patch Path.exists before importing
    orig_exists = Path.exists

    def fake_exists(self):
        p = str(self)
        if missing == "yolo" and p.endswith("yolov8s-seg.pt"):
            return False
        if missing == "tflite" and p.endswith("cow_model.tflite"):
            return False
        return orig_exists(self)

    monkeypatch.setattr(Path, "exists", fake_exists, raising=False)

    # Import in a try/except to assert the FileNotFoundError on module import
    with pytest.raises(FileNotFoundError):
        import cow_api.server  # noqa: F401
        importlib.reload(cow_api.server)  # execute top-level checks


# --------- 2) Names fallback + invalid-crop defensive branch in preprocess ----

def test_preprocess_invalid_crop_and_names_fallback(monkeypatch, fresh_server):
    """
    Use a 1‑pixel‑high bbox so best_idx is selected (area>0) but trimming
    makes y2 == y1 -> triggers 'Invalid crop from detection'.
    Also ensure names fallback via result.model.names (results[0].names is None).
    """
    # bbox: y1=10, y2=11 (height=1) -> after trim: y2 = 10 + int(1*0.7) = 10
    boxes = _Boxes(cls_ids=[0], xyxy=[[2, 10, 30, 11]])
    mask = np.ones((8, 8), dtype=np.uint8)
    masks = _Masks([mask])
    fake = _FakeResult(boxes=boxes, masks=masks, names=None, model_names={0: "cow"})
    monkeypatch.setattr(fresh_server, "yolo_model", lambda img: [fake])

    with pytest.raises(ValueError) as e:
        fresh_server.preprocess_image_with_yolo(_png_bytes())
    assert "Invalid crop" in str(e.value)



# ------------------- 3) /predict-multiple error-path coverage ----------------

def test_predict_multiple_no_files_returns_400(fresh_server):
    client = fresh_server.app.test_client()
    resp = client.post("/predict-multiple", data={}, content_type="multipart/form-data")
    assert resp.status_code == 400
    assert resp.get_json()["error"] == "No images uploaded"


def test_predict_multiple_per_item_error_mapping(monkeypatch, fresh_server):
    """
    Hit the per-item error append path in /predict-multiple by making
    preprocess raise ValueError('Invalid image payload') on one item and
    'No cow detected...' on the other.
    """
    client = fresh_server.app.test_client()

    calls = {"i": 0}
    def fake_preprocess(_bytes):
        i = calls["i"]; calls["i"] += 1
        if i == 0:
            raise ValueError("Invalid image payload")
        raise ValueError("No cow detected in the image.")

    monkeypatch.setattr(fresh_server, "preprocess_image_with_yolo", fake_preprocess)

    data = {
        "images": [
            (io.BytesIO(b"abc"), "bad1.bin"),
            (io.BytesIO(_png_bytes()), "nocow.png"),
        ]
    }
    resp = client.post("/predict-multiple", data=data, content_type="multipart/form-data")
    assert resp.status_code == 200
    items = resp.get_json()
    assert len(items) == 2
    assert items[0]["prediction"] == "No cow detected"
    assert items[0]["error"] == "Could not read image"
    assert items[1]["prediction"] == "No cow detected"
    assert items[1]["error"] == "No cow detected in the image."


# ---------------- 4) Generic exception fallback in /predict endpoint ----------

def test_predict_generic_exception_maps_to_could_not_read_image(monkeypatch, fresh_server):
    client = fresh_server.app.test_client()

    def boom(_bytes):
        raise RuntimeError("unexpected!")

    monkeypatch.setattr(fresh_server, "preprocess_image_with_yolo", boom)

    resp = client.post(
        "/predict",
        data={"image": (io.BytesIO(_png_bytes()), "ok.png")},
        content_type="multipart/form-data",
    )
    assert resp.status_code == 400
    assert resp.get_json()["error"] == "Could not read image"


# ----------- 5) Defensive errors in resize_with_padding for coverage ----------

def test_resize_with_padding_rejects_empty_array(fresh_server):
    with pytest.raises(ValueError):
        fresh_server.resize_with_padding(np.array([], dtype=np.uint8))
