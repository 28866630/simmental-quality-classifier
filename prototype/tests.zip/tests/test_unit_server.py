# tests/test_unit_server.py
import io
from pathlib import Path
import numpy as np
import pytest
from PIL import Image, UnidentifiedImageError
from cow_api import server

SAMPLES = Path(__file__).parent / "samples"
COW_IMG = SAMPLES / "cow.jpg"
NOCOW_IMG = SAMPLES / "nocow.jpg"

# ---------- resize_with_padding: padding color & extreme aspect ratios --------

def test_resize_with_padding_corners_are_white():
    """Corners should be white (255,255,255) after padding."""
    arr = np.zeros((300, 50, 3), dtype=np.uint8) + 128  # tall, narrow
    out = server.resize_with_padding(arr, desired_size=224)
    h, w, _ = out.shape
    corners = np.array([out[0,0], out[0,w-1], out[h-1,0], out[h-1,w-1]], dtype=np.uint8)
    assert np.all(corners >= 250), f"Corners not white: {corners}"

def test_resize_with_padding_extreme_wide_and_tall_shapes():
    """Extreme aspect ratios still yield 224x224 and preserve content scale."""
    wide = np.zeros((40, 400, 3), dtype=np.uint8) + 200
    out_wide = server.resize_with_padding(wide, desired_size=224)
    assert out_wide.shape == (224, 224, 3)

    tall = np.zeros((400, 40, 3), dtype=np.uint8) + 200
    out_tall = server.resize_with_padding(tall, desired_size=224)
    assert out_tall.shape == (224, 224, 3)

def test_resize_with_padding_tiny_input_1x1():
    """Even a 1x1 image must upscale and pad to 224x224 without errors."""
    tiny = np.array([[[123, 231, 45]]], dtype=np.uint8)  # 1x1 RGB
    out = server.resize_with_padding(tiny, desired_size=224)
    assert out.shape == (224, 224, 3)

# ---------- preprocess_image_with_yolo: decoding robustness -------------------

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_preprocess_accepts_jpeg_bytes_and_normalizes():
    """JPEG decoding -> preprocess -> normalized tensor."""
    b = COW_IMG.read_bytes()
    tensor = server.preprocess_image_with_yolo(b)
    assert tensor.shape == (1, 224, 224, 3)
    assert tensor.dtype == np.float32
    assert 0.0 <= float(tensor.min()) <= 1.0
    assert 0.0 <= float(tensor.max()) <= 1.0

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_preprocess_accepts_png_bytes_and_normalizes():
    """Save the same image as PNG in-memory and ensure pipeline still works."""
    img = Image.open(COW_IMG).convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    tensor = server.preprocess_image_with_yolo(buf.getvalue())
    assert tensor.shape == (1, 224, 224, 3)
    assert 0.0 <= float(tensor.min()) <= 1.0

def test_preprocess_handles_invalid_bytes_gracefully():
    """Invalid image bytes should raise an error or return None."""
    bad_bytes = b"not an image at all"
    with pytest.raises((UnidentifiedImageError, ValueError, OSError)):
        server.preprocess_image_with_yolo(bad_bytes)

# ---------- end-to-end: preprocessing + TFLite still bounded ------------------

@pytest.mark.skipif(not COW_IMG.exists(), reason="Missing tests/samples/cow.jpg")
def test_inference_remains_bounded_across_formats():
    """Run JPEG and PNG of the same photo; both scores should be in [0,1]."""
    # JPEG
    t_jpg = server.preprocess_image_with_yolo(COW_IMG.read_bytes())
    server.interpreter_cow.set_tensor(server.input_details_cow[0]['index'], t_jpg)
    server.interpreter_cow.invoke()
    s_jpg = float(server.interpreter_cow.get_tensor(server.output_details_cow[0]['index'])[0][0])
    assert 0.0 <= s_jpg <= 1.0

    # PNG
    img = Image.open(COW_IMG).convert("RGB")
    buf = io.BytesIO(); img.save(buf, "PNG"); buf.seek(0)
    t_png = server.preprocess_image_with_yolo(buf.getvalue())
    server.interpreter_cow.set_tensor(server.input_details_cow[0]['index'], t_png)
    server.interpreter_cow.invoke()
    s_png = float(server.interpreter_cow.get_tensor(server.output_details_cow[0]['index'])[0][0])
    assert 0.0 <= s_png <= 1.0

# ---------- "remove features" simulation (empty/cleared inputs) ---------------

def test_preprocess_empty_bytes_behaves_like_removed_image():
    """Empty input (as if user cleared selection) should error cleanly."""
    with pytest.raises(ValueError):
        server.preprocess_image_with_yolo(b"")

def test_inference_with_no_input_does_not_crash():
    """Simulate cleared images list -> interpreter should not be invoked."""
    # just make sure interpreter not called with empty tensor
    empty_tensor = np.zeros((0,))  # nothing
    with pytest.raises(Exception):
        server.interpreter_cow.set_tensor(server.input_details_cow[0]['index'], empty_tensor)
