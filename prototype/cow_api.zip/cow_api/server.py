# app/cow_api/server.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
import numpy as np
import io
from PIL import Image, UnidentifiedImageError
import cv2
from ultralytics import YOLO
from pathlib import Path
from typing import Optional

app = Flask(__name__)
CORS(app)

# ── Resolve model files relative to this file ────────────────────────────────
MODEL_DIR = Path(__file__).resolve().parent
YOLO_WEIGHTS = MODEL_DIR / "yolov8s-seg.pt"
TFLITE_PATH = MODEL_DIR / "cow_model.tflite"

if not YOLO_WEIGHTS.exists():
    raise FileNotFoundError(f"Missing YOLO weights: {YOLO_WEIGHTS}")
if not TFLITE_PATH.exists():
    raise FileNotFoundError(f"Missing TFLite model: {TFLITE_PATH}")

# === Load YOLOv8 model (segmentation) ===
yolo_model = YOLO(str(YOLO_WEIGHTS))

# === Load only the COW TFLite model ===
interpreter_cow = tf.lite.Interpreter(model_path=str(TFLITE_PATH))
interpreter_cow.allocate_tensors()
input_details_cow = interpreter_cow.get_input_details()
output_details_cow = interpreter_cow.get_output_details()

# === Resize with padding (square to 224x224) ===
def resize_with_padding(image: np.ndarray, desired_size: int = 224) -> np.ndarray:
    if image is None or image.size == 0:
        raise ValueError("Empty image array passed to resize_with_padding")
    old_h, old_w = image.shape[:2]
    if old_h == 0 or old_w == 0:
        raise ValueError("Zero-sized image passed to resize_with_padding")
    scale = float(desired_size) / max(old_h, old_w)
    new_h, new_w = max(1, int(old_h * scale)), max(1, int(old_w * scale))
    resized = cv2.resize(image, (new_w, new_h))
    delta_w, delta_h = desired_size - new_w, desired_size - new_h
    top, bottom = delta_h // 2, delta_h - (delta_h // 2)
    left, right = delta_w // 2, delta_w - (delta_w // 2)
    return cv2.copyMakeBorder(
        resized, top, bottom, left, right,
        cv2.BORDER_CONSTANT, value=[255, 255, 255]
    )

# === YOLO preprocessing: segment, mask background, crop, pad ===
def preprocess_image_with_yolo(image_bytes: bytes) -> np.ndarray:
    if image_bytes is None or len(image_bytes) == 0:
        raise ValueError("Empty image payload")

    try:
        pil_image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except (UnidentifiedImageError, OSError) as e:
        # Normalize PIL errors so callers can branch on a single message
        raise ValueError("Invalid image payload") from e

    image_rgb = np.array(pil_image)
    H, W = image_rgb.shape[:2]
    if H == 0 or W == 0:
        raise ValueError("Invalid image payload")

    results = yolo_model(image_rgb)

    if not results or results[0].masks is None or len(results[0].masks.data) == 0:
        raise ValueError("No cow detected in the image.")

    masks = results[0].masks
    boxes = results[0].boxes
    names: Optional[dict] = getattr(results[0], "names", None)
    if names is None:
        names = getattr(getattr(results[0], "model", None), "names", {})

    best_idx, best_area = None, 0
    for i, cls_id in enumerate(boxes.cls.cpu().numpy()):
        cls_name = names.get(int(cls_id), str(int(cls_id)))
        if cls_name != "cow":
            continue
        x1, y1, x2, y2 = map(int, boxes.xyxy[i].cpu().numpy())
        area = max(0, x2 - x1) * max(0, y2 - y1)
        if area > best_area:
            best_idx, best_area = i, area

    if best_idx is None:
        raise ValueError("No cow detected in the image.")

    mask = masks.data[best_idx].cpu().numpy()
    mask_resized = cv2.resize(mask, (W, H), interpolation=cv2.INTER_NEAREST)
    mask_3 = np.stack([mask_resized] * 3, axis=-1)
    masked = np.where(mask_3 > 0.5, image_rgb, 255)

    x1, y1, x2, y2 = map(int, boxes.xyxy[best_idx].cpu().numpy())
    margin = 0.1
    bw, bh = max(1, x2 - x1), max(1, y2 - y1)
    x1 = max(0, x1 - int(bw * margin))
    x2 = min(W, x2 + int(bw * margin))
    y2 = y1 + int(bh * 0.7)  # keep top 70%
    x1, x2 = max(0, x1), min(W, x2)
    y1, y2 = max(0, y1), min(H, y2)
    if x2 <= x1 or y2 <= y1:
        raise ValueError("Invalid crop from detection")

    cropped = masked[y1:y2, x1:x2]
    if cropped.size == 0:
        raise ValueError("Invalid crop from detection (empty)")

    resized = resize_with_padding(cropped, desired_size=224).astype(np.float32) / 255.0
    return np.expand_dims(resized, axis=0)

# --- helper to map internal errors to API messages expected by tests ----------
def _public_error_message(e: ValueError) -> str:
    msg = str(e)
    # Tests expect "Could not read image" for corrupt/unsupported bytes
    if "Invalid image payload" in msg:
        return "Could not read image"
    # Pass through other validated messages (e.g., Empty payload / No cow detected)
    return msg

# === Single-image prediction endpoint =======================================
@app.route("/predict", methods=["POST"])
def predict():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    filename = request.files["image"].filename or "(unnamed)"
    image_bytes = request.files["image"].read()

    try:
        input_data = preprocess_image_with_yolo(image_bytes)
    except ValueError as e:
        pub = _public_error_message(e)
        app.logger.info(f"[predict] filename={filename} -> error={pub}")
        return jsonify({"error": pub}), 400
    except Exception:
        app.logger.exception(f"[predict] filename={filename} -> unexpected error")
        return jsonify({"error": "Could not read image"}), 400

    interpreter_cow.set_tensor(input_details_cow[0]['index'], input_data)
    interpreter_cow.invoke()
    output = interpreter_cow.get_tensor(output_details_cow[0]['index'])[0]

    score = float(output[0])
    label = "Good" if score > 0.5 else "Bad"

    app.logger.info(f"[predict] filename={filename} -> label={label}, score={score:.4f}")

    return jsonify({
        "prediction": label,
        "score": score,
        "model_used": "cow"
    })

# === Multi-image prediction endpoint ========================================
@app.route("/predict-multiple", methods=["POST"])
def predict_multiple():
    """
    Accept multiple files under field name 'images'.
    Returns a list of prediction objects, one per file, preserving order.
    """
    files = request.files.getlist("images")
    if not files:
        return jsonify({"error": "No images uploaded"}), 400

    results = []
    for f in files:
        filename = f.filename or "(unnamed)"
        image_bytes = f.read()

        try:
            input_data = preprocess_image_with_yolo(image_bytes)
        except ValueError as e:
            pub = _public_error_message(e)
            app.logger.info(f"[predict-multiple] filename={filename} -> error={pub}")
            results.append({
                "prediction": "No cow detected" if pub == "No cow detected in the image." else "No cow detected",
                "score": None,
                "model_used": "cow",
                "filename": filename,
                "error": pub,
            })
            continue
        except Exception:
            app.logger.exception(f"[predict-multiple] filename={filename} -> unexpected error")
            results.append({
                "prediction": "No cow detected",
                "score": None,
                "model_used": "cow",
                "filename": filename,
                "error": "Could not read image",
            })
            continue

        interpreter_cow.set_tensor(input_details_cow[0]['index'], input_data)
        interpreter_cow.invoke()
        output = interpreter_cow.get_tensor(output_details_cow[0]['index'])[0]
        score = float(output[0])
        label = "Good" if score > 0.5 else "Bad"

        app.logger.info(f"[predict-multiple] filename={filename} -> label={label}, score={score:.4f}")

        results.append({
            "prediction": label,
            "score": score,
            "model_used": "cow",
            "filename": filename
        })

    return jsonify(results), 200

# ============================================================================

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=True)
